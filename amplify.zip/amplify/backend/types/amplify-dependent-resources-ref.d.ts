export type AmplifyDependentResourcesAttributes = {
    "auth": {
        "dumplingapp74507e7574507e75": {
            "UserPoolId": "string",
            "UserPoolArn": "string",
            "UserPoolName": "string",
            "AppClientIDWeb": "string",
            "AppClientID": "string",
            "CreatedSNSRole": "string"
        }
    }
}